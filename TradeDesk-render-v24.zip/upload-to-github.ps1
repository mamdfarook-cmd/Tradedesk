# Uploads the TradeDesk folder next to this script to your GitHub repository with Git (instead of the web page).
# The repository then holds exactly these files - stale ones (e.g. an old PUBLIC folder) are removed - and its
# history is kept. Render redeploys by itself after the push.
# Run: right-click -> Run with PowerShell, or in PowerShell:  .\upload-to-github.ps1
param(
  [string]$Repo   = 'https://github.com/mamdfarook-cmd/Tradedesk.git',
  [string]$Branch = 'main'
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src  = Join-Path $here 'TradeDesk'
if (-not (Test-Path (Join-Path $src 'server.js'))) { Write-Host "TradeDesk folder not found next to this script ($src)."; exit 1 }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Write-Host 'Git is not installed. Install it from https://git-scm.com/download/win and run this again.'; exit 1 }

$tmp = Join-Path $env:TEMP ('tradedesk-upload-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
Write-Host "Cloning $Repo ..."
git clone --branch $Branch $Repo $tmp        # GitHub asks you to sign in the first time
if ($LASTEXITCODE -ne 0) { Write-Host 'Clone failed - check the repository address and that you can sign in to it.'; exit 1 }

Get-ChildItem -LiteralPath $tmp -Force | Where-Object { $_.Name -ne '.git' } | Remove-Item -Recurse -Force
Get-ChildItem -LiteralPath $src -Force | Copy-Item -Destination $tmp -Recurse -Force

Push-Location $tmp
try {
  # Windows treats public and PUBLIC as one folder, Render (Linux) does not: an old PUBLIC/ in the repository
  # would swallow the new public/ files. Clear Git's file list and add every path with its exact case.
  git config core.ignorecase false
  git rm -r -q --cached . 2>$null
  git add -A
  git add -f data/universe.json 2>$null       # starting stock list (data/ is otherwise ignored)
  Write-Host ''
  Write-Host 'Changes to upload:'
  git status --short
  $ok = Read-Host 'Upload these changes to GitHub? (y/n)'
  if ($ok -ne 'y') { Write-Host 'Nothing uploaded.'; exit 0 }
  $who = @()
  if (-not (git config user.email)) { $who = @('-c', 'user.name=TradeDesk upload', '-c', 'user.email=tradedesk@users.noreply.github.com') }
  git @who commit -m ('TradeDesk update ' + (Get-Date -Format 'yyyy-MM-dd HH:mm'))
  git push origin $Branch
  if ($LASTEXITCODE -eq 0) { Write-Host 'Uploaded. Render starts a new deploy by itself - watch it under Events / Logs.' }
} finally { Pop-Location }
